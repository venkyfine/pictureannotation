//
//  LoginViewController.swift
//  OktaDemo

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var tfUsername: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    
    var viewModel = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func loginPressed(_ sender: UIButton) {
        viewModel.login(username: tfUsername.text!, password: tfPassword.text!) { idToken in
            print(idToken)
        } failure: { message in
            print(message)
        }
    }

}

